def multyp2(x):
    return 2 * x
